Что это: служебный отчёт машинных проверок, не загружать как знания.
Статус: черновик, ещё не правило; руководителем отдела не утверждено.
Источник: программа сборки и сохранённые исходники.
Редакция: 2026-11-18.
Ссылаться: служебный отчёт машинных проверок, не загружать как знания; имя файла и заголовок раздела.

# Проверка выпуска

- Акты: 14, каждый в отдельном файле. Это подборка статей/пунктов, не законы целиком.
- Реально в `rutina/akty.csv`: **90 строк**, полученных текстов — **89**, не получено — **1**.
- Нет текста: ТК РФ, статья 317; сохранена отметка об ошибке получения, норма не придумана.
- Маршруты: 42, шагов с полным названием маршрута: 904. Словарь: 142 написания / 96 ролей. Сверка NDA 21/42 включена как черновик.
- Проверено посимвольно: 2344 исходных цитатных строк; удаление только добавленных меток восстанавливает строки источников без изменения пробелов, букв, знаков и редакционных примечаний. Проверка сравнивает также сами метки с результатом алгоритма.
- Три коллекции: {'marshruty': 42, 'materialy': 7, 'zakony': 14}; служебные файлы корня не загружать.
- Контроль: 13 вопросов, 11 ответов найдены точным поиском в указанных файлах; 2 отсутствующих текста проверены по составу источников. Системный промпт: 1126 знаков текста, 1398 знаков с паспортом и заголовком, предел 1500.
- Проверены UTF-8, только .md, уникальные латинские имена, паспорта всех файлов, отсутствие README, HTML, JSON, программ и типовых признаков личных данных/секретов. Автоматический поиск не является доказательством отсутствия любых персональных данных; проверен также отбор источников.
- В выпуск взяты только файлы улья из таблицы ниже. Маршруты взяты из готовых описаний.
- Сводка полугода собрана программой rutina/za_period.py по всей подборке; даты законов, не даты вступления в силу.
- Нет сетевых запросов, API и проверки живой модели. Актуальность сохранённых норм и юридическую правильность меток подтверждает юрист; выпуск сам ничего не утверждает.

## Воспроизведение

`python3 -I rutina/knowledge_build.py --self-test` — сборка и отрицательные тесты в памяти.

`python3 -I rutina/knowledge_build.py --check` — проверка существующей папки и архива без записи.

Zip имеет фиксированные даты записей и порядок файлов; повторная сборка тех же исходников даёт идентичные байты. Исходники и сторонние изменения не изменяются.

## Источники и SHA-256

| Файл источника | SHA-256 |
|:--|:--|
| rutina/akty.csv | 494ba87d308f2e1992feb6767a5cc95442f80459d6a3cf26737137b1bfacd24d |
| zakony/ofm.md | 8e46d79a200ede6bb981470ea7f0b61087d549fc519fa3e671a602ba59eea83a |
| zakony/licenzii-po.md | d37f8aeaf294d200c0c80776c52d5275ab274673fa41ef2ff00e6ce460d2292c |
| zakony/reklama-potrebiteli.md | 3a74e129a01c7371c6bd8372050e1e8089b2bb2b05bfed18933e3f36ca629771 |
| zakony/pdn-edo.md | c9eea70efcae95482b53321e6769408b649dbab7a8acb6ac801d5af95b1b12b4 |
| zakony/trud.md | d02bbd43171a89ebca29356f7ed5e9a66c769d643825e6f7f390d0e67a760713 |
| zakony/voinskiy-uchet.md | 79c4498d23c5bba8550247750c57790436045b1efb57b1c98f487a42470e8615 |
| chernoviki/marshruty/m01-vhodyaschaya-korrespondenciya.md | a4ae928da33504397c45a3122e5564acc1ccc9b76c321451eccdf3ef6bce8530 |
| chernoviki/marshruty/m02-dkp-tehniki.md | ce7cc5ceb075a6ef509d476962d8f5f4c4ce263111f0f4e31b6a90f05a8b7a76 |
| chernoviki/marshruty/m03-dogovor-zayma.md | a699b2973a07af81ed56d53f11936c6a6260041503ee24f08ac773bc3506aef0 |
| chernoviki/marshruty/m04-kartochka-soglasuyuschego-doverennost.md | d3530448c3683aaf8fb19d578414c65f80b7a5bb805ffdad6e00efc9da341083 |
| chernoviki/marshruty/m05-kartochka-soglasuyuschego-dogovor.md | a4f2f6f3e15545f7d9c5d2814c0ce2dc85d2756476b9d6d8ae4913c60fac9b53 |
| chernoviki/marshruty/m06-kartochka-soglasuyuschego-dopolnitelnoe-soglashenie.md | bda3129eab6ea4d1cc50d26bf50f3eb1dcdd8962bd39366358fd44ca2e5ce124 |
| chernoviki/marshruty/m07-kartochka-soglasuyuschego-proverku-kontragenta.md | b361a4eb0170fae9a8ce46ba2ed460377dabfcd6fe8a45abb6c0748337dd1449 |
| chernoviki/marshruty/m08-process-razrabotki-i-sozdaniya-nma.md | 0a8dc93519113aab1502b41bbb59df9870a7f5e8a9ce36126e8f8aeba760d8f3 |
| chernoviki/marshruty/m09-process-soglasovaniya-doverennosti-kartochka.md | 1f2c986edb2d12836d68752d9f02aaaed6477e82d128799446dce47310ffcb98 |
| chernoviki/marshruty/m10-process-sozdaniya-i-soglasovaniya-kartochki-kontragenta.md | 5dc1a54cbd35a4ba63cfbfcb7e11523380d0184c417a12ccd87c257ffa61b747 |
| chernoviki/marshruty/m11-process-sozdaniya-kartochki-ds.md | 260c0d6f6c298b871cfb02a0ad7983c6e6e78fce50035b87b5d5cbc965b202eb |
| chernoviki/marshruty/m12-process-sozdaniya-kartochki-doverennosti.md | 4f331abbc2973a94bd6a424d7ed573a8ac4aa6d8c03f09e71b9abf9cb40b9364 |
| chernoviki/marshruty/m13-process-sozdaniya-kartochki-dogovora.md | 1f5e958b233bcec20d7f634aa939437737b8a4a2d7a018c23f3766dbd0464ec7 |
| chernoviki/marshruty/m14-process-sozdaniya-shablona-dogovora.md | 99089a4fdf4cb3c5a4a9ada8940444b4a5b2b18de3d69327f95d575eb5137ecc |
| chernoviki/marshruty/m15-soglasovanie-gph-dogovora-s-fl.md | 99422cf057c99ba6687ee85ba13980e384a35e08b81e0efbe4fc0e4225a330b8 |
| chernoviki/marshruty/m16-soglasovanie-lna.md | c94b8dd80b8f6b25d039a47b15aa1c1c57d2536d07378a28bab01682e691ab24 |
| chernoviki/marshruty/m17-soglasovanie-dohodnogo-dogovora.md | c811b6e7bbe577195e7d9eb4d67aafc2697a0829a95c439ebb3860ff4730a648 |
| chernoviki/marshruty/m18-soglasovanie-prikazov.md | a3e2890bc7eebd4a25c9e5585c93769c0e319e2ff3c1725f0dfd577689a6dc24 |
| chernoviki/marshruty/m19-soglasovanie-rashodnogo-dogovora.md | 459e4d524e0adf7911b7e1128aeda18883dd3598d84b897400ed245366c007d5 |
| chernoviki/marshruty/m20-tender-dohodnyy.md | 8efd6035a670f6dd562c3bae6142b912d5a63fe921d60a0a3c1521bd9bcba88e |
| chernoviki/marshruty/m21-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-a.md | d4a46cd2c9531bfeb4a7953dc894fcf7d550ec5e529728d63ac4e95531af0eaf |
| chernoviki/marshruty/m22-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-b.md | fb7239078ec41d8b439499fa47a6d67800957faba9234cd4440131d52baab749 |
| chernoviki/marshruty/m23-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-v.md | bac60f180cac9c49cd6cd9e5929c70b82d9a09ea98c4b5aae90de5032784979a |
| chernoviki/marshruty/m24-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-g.md | c15aa807f971556b1b04d8e8dd6f80e47b39e0d3b86be740963da029cdc01bb3 |
| chernoviki/marshruty/m25-tipy-dokumentov-i-ih-klassifikaciya.md | 59b2291f8fb2e99c8108a34af10c926047d680470a2b44c1c63485afa199c9d4 |
| chernoviki/marshruty/m26-process-sozdaniya-kartochki-dogovora.md | 0722327c8adec4bda86e88f2b3d67f2a3c0e765d2c9a109a75df0e886de2aa36 |
| chernoviki/marshruty/m27-soglasovanie-ds-k-dohodnomu-dogovoru.md | c22fcc4431dfe13275aac4f00e32e213cf456267f48071eb330380824ab7fe1e |
| chernoviki/marshruty/m28-soglasovanie-ds.md | 5c83233ff37810d2304d01568e336d225b21d16aa5ecaa36799043b60c689460 |
| chernoviki/marshruty/m29-soglasovanie-dohodnogo-dogovora-po-reglamentu.md | 571bb1cc4a115bae6603e39f1277cd530b98dfdc29f8fd2f29763f20f48dd642 |
| chernoviki/marshruty/m30-klassifika-ciya-dokumentov-i-zadach.md | 852c670314f4a78583e8588c29f4331d07bea560631812ce2b23e3c1877403a8 |
| chernoviki/marshruty/m31-formirovanie-edinogo-yuridicheski-znachimogo-dela.md | d4ee438792e964cad6df9293e735338712c062cd4a3dab9c6d75cdec5b256059 |
| chernoviki/marshruty/m32-proverka-kontragenta-i-soglasovanie-zaprosa.md | 9d913a4d1232c72f3188ae761c509826a92f3c0546eb795e09d554754027393a |
| chernoviki/marshruty/m33-tz-sesd-ofm-11.md | 4639bb262703908d1c006004a479a274ca82a07b4c0020127a2ba4d6358cf86e |
| chernoviki/marshruty/m34-prisoedinenie-fo-k-pravilam-ofp.md | e49b113bdea15f06478340be416a880b7d3742767ca9a5bbb74a47ec3e0faf68 |
| chernoviki/marshruty/m35-nda-dohodnyy-marshrut-b.md | d8ba0deb59b0c2ad25603de5ec03b23367deeda6a6b1d7904e844d23a4ef4781 |
| chernoviki/marshruty/m36-prekraschenie-dopuska-fo-k-sdelkam.md | e20e7fa430d1f973588b7b28ff02bfe53ffe51bcc4b5f0a3ffa4a34a4548a1ca |
| chernoviki/marshruty/m37-soglasovanie-oferty.md | 33d40fdd3686be0ff7f6bec3be43bb7587ac3c63f1a42ec0e47249ed761816aa |
| chernoviki/marshruty/m38-klassifikaciya-dokumentov.md | b7d229588cc5988ae668a489933ca7af31c5d3045d48f2639f2a337f9d92f518 |
| chernoviki/marshruty/m39-nda-dohodnyy-marshrut-v.md | fb6051b8617d800c4966d464e81d643341e4b0d78d9bfe11f2e96392796ea60f |
| chernoviki/marshruty/m40-marshrut-soglasovaniya-i-podpisaniya-dogovora.md | 96fa3d7f17cc851d289b48d4f734c8548370076ea93bffd39f6ca895175037a9 |
| chernoviki/marshruty/m41-vypusk-doverennosti.md | 9b0c5c69272063a9e7850b57f448b08b794b65e042846b4ef21dbc21bd4934d2 |
| chernoviki/marshruty/m42-nda-dohodnyy-marshrut-a.md | d96bb0a7032c0389b45c40a8332f63fa0d4fe7bbc267db4bf2048093aeb75e5e |
| chernoviki/marshruty/roli.md | 61896cc0356fcc201d254f6509e5ccfb78bd9fc56e4afe1d9d2ecac103cbf46e |
| chernoviki/marshruty/sverka-nda-a.md | cb6d6455473c3bb632051395004f0aa28115269a3a97a75e88b072614acfc41b |
| pasporta/_shablon.md | 4b999a2050089aa373342481571321e09f8dacf7802081b78fbec7b6ec18f660 |
| chernoviki/poruchenie-pasport-proekta.md | 2b8aeaf25f41cd227ac1394ec64bcd18fba5d2df988cb404c71fbc2df65fcb9a |
| chernoviki/poruchenie-chto-zacepit-izmenenie.md | db46ec6593f39d23a5ecd13c219e9ce001befbe6ee03199098faaedd13a67fda |
| svodka/izmeneniya_2026-05-11_2026-11-11.md | 8b898a9e2daf5efd7ada538fe1f2b0288a07fc47d4d64983a474f189acef5564 |
| rutina/knowledge_build.py | bb7a1596e78669764eb771157c4df8ac15f3cff54c388f240b154662fe2cd61c |
