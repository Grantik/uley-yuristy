Что это: карта файлов выпуска Knowledge.
Статус: черновик, ещё не правило; руководителем отдела не утверждено.
Источник: программа сборки и состав выпуска.
Редакция: 2026-11-18.
Ссылаться: карта файлов выпуска Knowledge; имя файла и заголовок раздела.

# Карта выпуска Knowledge

В выпуске 14 актов: подборка 90 статей/пунктов, из них 89 с текстом. Это не все законы целиком. ТК РФ, статья 317 не получена; статья 3 ЗоЗПП не включалась. Маршруты, роли, поручения, сверка и шаблон — черновики, не правила отдела.

## Карта выпуска — коллекция zakony

- [zakon-elektronnaya-podpis-63-fz.md](../zakony/zakon-elektronnaya-podpis-63-fz.md) — Федеральный закон «Об электронной подписи», 63-ФЗ; статьи/пункты 5, 6, 9; вопросы по этим нормам и их редакции.
- [zakon-finansovaya-platforma-211-fz.md](../zakony/zakon-finansovaya-platforma-211-fz.md) — Федеральный закон «О совершении финансовых сделок с использованием финансовой платформы», 211-ФЗ; статьи/пункты 2, 3, 4, 8, 11, 16; вопросы по этим нормам и их редакции.
- [zakon-gk-ch4-230-fz.md](../zakony/zakon-gk-ch4-230-fz.md) — Гражданский кодекс, часть четвёртая, 230-ФЗ; статьи/пункты 1235, 1238, 1286; вопросы по этим нормам и их редакции.
- [zakon-informaciya-149-fz.md](../zakony/zakon-informaciya-149-fz.md) — Федеральный закон «Об информации, информационных технологиях и о защите информации», 149-ФЗ; статьи/пункты 11; вопросы по этим нормам и их редакции.
- [zakon-koap-195-fz.md](../zakony/zakon-koap-195-fz.md) — Кодекс об административных правонарушениях, 195-ФЗ; статьи/пункты 14.3; вопросы по этим нормам и их редакции.
- [zakon-nk-ch2-117-fz.md](../zakony/zakon-nk-ch2-117-fz.md) — Налоговый кодекс, часть вторая, 117-ФЗ; статьи/пункты 149; вопросы по этим нормам и их редакции.
- [zakon-personalnye-dannye-152-fz.md](../zakony/zakon-personalnye-dannye-152-fz.md) — Федеральный закон «О персональных данных», 152-ФЗ; статьи/пункты 3, 6, 9, 10, 11, 18, 18.1, 19, 21; вопросы по этим нормам и их редакции.
- [zakon-pod-ft-115-fz.md](../zakony/zakon-pod-ft-115-fz.md) — Федеральный закон «О противодействии легализации (отмыванию) доходов, полученных преступным путем, и финансированию терроризма», 115-ФЗ; статьи/пункты 5, 7; вопросы по этим нормам и их редакции.
- [zakon-potrebitelskiy-kredit-353-fz.md](../zakony/zakon-potrebitelskiy-kredit-353-fz.md) — Федеральный закон «О потребительском кредите (займе)», 353-ФЗ; статьи/пункты 3, 5; вопросы по этим нормам и их редакции.
- [zakon-reklama-38-fz.md](../zakony/zakon-reklama-38-fz.md) — Федеральный закон «О рекламе», 38-ФЗ; статьи/пункты 3, 18.1, 28; вопросы по этим нормам и их редакции.
- [zakon-tk-197-fz.md](../zakony/zakon-tk-197-fz.md) — Трудовой кодекс Российской Федерации, 197-ФЗ; статьи/пункты 8, 22, 22.1, 22.2, 22.3, 60.2, 68, 72, 74, 96, 97, 99, 101, 104, 111, 112, 113, 114, 115, 116, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129, 135, 139, 146, 148, 151, 152, 153, 154, 166, 167, 168, 189, 190, 191, 259, 264, 268, 315, 316, 317 (текста нет), 372; вопросы по этим нормам и их редакции.
- [zakon-voinskaya-obyazannost-53-fz.md](../zakony/zakon-voinskaya-obyazannost-53-fz.md) — Федеральный закон «О воинской обязанности и военной службе», 53-ФЗ; статьи/пункты 4; вопросы по этим нормам и их редакции.
- [zakon-voinskiy-uchet-pp719.md](../zakony/zakon-voinskiy-uchet-pp719.md) — Положение о воинском учёте (Постановление Правительства РФ от 27.11.2006 № 719), ПП 719; статьи/пункты п. 9, п. 12, п. 30, п. 32; вопросы по этим нормам и их редакции.
- [zakon-zozpp-2300-1.md](../zakony/zakon-zozpp-2300-1.md) — Закон «О защите прав потребителей», 2300-1; статьи/пункты 10, 16; вопросы по этим нормам и их редакции.
## Карта выпуска — коллекция marshruty

- [marshrut-01-vhodyaschaya-korrespondenciya.md](../marshruty/marshrut-01-vhodyaschaya-korrespondenciya.md) — Маршрут 01 «Входящая корреспонденция»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-02-dkp-tehniki.md](../marshruty/marshrut-02-dkp-tehniki.md) — Маршрут 02 «ДКП техники»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-03-dogovor-zayma.md](../marshruty/marshrut-03-dogovor-zayma.md) — Маршрут 03 «Договор займа»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-04-kartochka-soglasuyuschego-doverennost.md](../marshruty/marshrut-04-kartochka-soglasuyuschego-doverennost.md) — Маршрут 04 «Карточка согласующего Доверенность»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-05-kartochka-soglasuyuschego-dogovor.md](../marshruty/marshrut-05-kartochka-soglasuyuschego-dogovor.md) — Маршрут 05 «Карточка согласующего Договор»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-06-kartochka-soglasuyuschego-dopolnitelnoe-soglashenie.md](../marshruty/marshrut-06-kartochka-soglasuyuschego-dopolnitelnoe-soglashenie.md) — Маршрут 06 «Карточка согласующего Дополнительное соглашение»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-07-kartochka-soglasuyuschego-proverku-kontragenta.md](../marshruty/marshrut-07-kartochka-soglasuyuschego-proverku-kontragenta.md) — Маршрут 07 «Карточка согласующего проверку Контрагента»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-08-process-razrabotki-i-sozdaniya-nma.md](../marshruty/marshrut-08-process-razrabotki-i-sozdaniya-nma.md) — Маршрут 08 «Процесс разработки и создания НМА»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-09-process-soglasovaniya-doverennosti-kartochka.md](../marshruty/marshrut-09-process-soglasovaniya-doverennosti-kartochka.md) — Маршрут 09 «Процесс согласования доверенности-Карточка»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-10-process-sozdaniya-i-soglasovaniya-kartochki-kontragenta.md](../marshruty/marshrut-10-process-sozdaniya-i-soglasovaniya-kartochki-kontragenta.md) — Маршрут 10 «Процесс создания и согласования карточки Контрагента»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-11-process-sozdaniya-kartochki-ds.md](../marshruty/marshrut-11-process-sozdaniya-kartochki-ds.md) — Маршрут 11 «Процесс создания карточки ДС»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-12-process-sozdaniya-kartochki-doverennosti.md](../marshruty/marshrut-12-process-sozdaniya-kartochki-doverennosti.md) — Маршрут 12 «Процесс создания карточки Доверенности»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-13-process-sozdaniya-kartochki-dogovora.md](../marshruty/marshrut-13-process-sozdaniya-kartochki-dogovora.md) — Маршрут 13 «Процесс создания карточки договора»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-14-process-sozdaniya-shablona-dogovora.md](../marshruty/marshrut-14-process-sozdaniya-shablona-dogovora.md) — Маршрут 14 «Процесс создания шаблона договора»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-15-soglasovanie-gph-dogovora-s-fl.md](../marshruty/marshrut-15-soglasovanie-gph-dogovora-s-fl.md) — Маршрут 15 «Согласование ГПХ договора с ФЛ»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-16-soglasovanie-lna.md](../marshruty/marshrut-16-soglasovanie-lna.md) — Маршрут 16 «Согласование ЛНА»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-17-soglasovanie-dohodnogo-dogovora.md](../marshruty/marshrut-17-soglasovanie-dohodnogo-dogovora.md) — Маршрут 17 «Согласование доходного договора»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-18-soglasovanie-prikazov.md](../marshruty/marshrut-18-soglasovanie-prikazov.md) — Маршрут 18 «Согласование приказов»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-19-soglasovanie-rashodnogo-dogovora.md](../marshruty/marshrut-19-soglasovanie-rashodnogo-dogovora.md) — Маршрут 19 «Согласование расходного договора»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-20-tender-dohodnyy.md](../marshruty/marshrut-20-tender-dohodnyy.md) — Маршрут 20 «Тендер (доходный)»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-21-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-a.md](../marshruty/marshrut-21-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-a.md) — Маршрут 21 «Типовой маршрут согласования NDA (доходный). Маршрут А»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-22-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-b.md](../marshruty/marshrut-22-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-b.md) — Маршрут 22 «Типовой маршрут согласования NDA (доходный). Маршрут Б»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-23-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-v.md](../marshruty/marshrut-23-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-v.md) — Маршрут 23 «Типовой маршрут согласования NDA (доходный). Маршрут В»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-24-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-g.md](../marshruty/marshrut-24-tipovoy-marshrut-soglasovaniya-nda-dohodnyy-marshrut-g.md) — Маршрут 24 «Типовой маршрут согласования NDA (доходный). Маршрут Г»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-25-tipy-dokumentov-i-ih-klassifikaciya.md](../marshruty/marshrut-25-tipy-dokumentov-i-ih-klassifikaciya.md) — Маршрут 25 «Типы документов и их классификация»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-26-process-sozdaniya-kartochki-dogovora.md](../marshruty/marshrut-26-process-sozdaniya-kartochki-dogovora.md) — Маршрут 26 «Процесс создания карточки договора»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-27-soglasovanie-ds-k-dohodnomu-dogovoru.md](../marshruty/marshrut-27-soglasovanie-ds-k-dohodnomu-dogovoru.md) — Маршрут 27 «Согласование ДС к доходному договору»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-28-soglasovanie-ds.md](../marshruty/marshrut-28-soglasovanie-ds.md) — Маршрут 28 «Согласование ДС»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-29-soglasovanie-dohodnogo-dogovora-po-reglamentu.md](../marshruty/marshrut-29-soglasovanie-dohodnogo-dogovora-po-reglamentu.md) — Маршрут 29 «Согласование доходного договора по регламенту»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-30-klassifika-ciya-dokumentov-i-zadach.md](../marshruty/marshrut-30-klassifika-ciya-dokumentov-i-zadach.md) — Маршрут 30 «Классифика ция документов и задач»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-31-formirovanie-edinogo-yuridicheski-znachimogo-dela.md](../marshruty/marshrut-31-formirovanie-edinogo-yuridicheski-znachimogo-dela.md) — Маршрут 31 «Формирование единого юридически значимого дела»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-32-proverka-kontragenta-i-soglasovanie-zaprosa.md](../marshruty/marshrut-32-proverka-kontragenta-i-soglasovanie-zaprosa.md) — Маршрут 32 «Проверка контрагента и согласование запроса»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-33-tz-sesd-ofm-11.md](../marshruty/marshrut-33-tz-sesd-ofm-11.md) — Маршрут 33 «ТЗ СЭСД ОФМ (11)»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-34-prisoedinenie-fo-k-pravilam-ofp.md](../marshruty/marshrut-34-prisoedinenie-fo-k-pravilam-ofp.md) — Маршрут 34 «Присоединение ФО к Правилам ОФП»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-35-nda-dohodnyy-marshrut-b.md](../marshruty/marshrut-35-nda-dohodnyy-marshrut-b.md) — Маршрут 35 «NDA (доходный). Маршрут Б.»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-36-prekraschenie-dopuska-fo-k-sdelkam.md](../marshruty/marshrut-36-prekraschenie-dopuska-fo-k-sdelkam.md) — Маршрут 36 «Прекращение Допуска ФО к сделкам»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-37-soglasovanie-oferty.md](../marshruty/marshrut-37-soglasovanie-oferty.md) — Маршрут 37 «Согласование Оферты»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-38-klassifikaciya-dokumentov.md](../marshruty/marshrut-38-klassifikaciya-dokumentov.md) — Маршрут 38 «Классификация документов»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-39-nda-dohodnyy-marshrut-v.md](../marshruty/marshrut-39-nda-dohodnyy-marshrut-v.md) — Маршрут 39 «NDA (доходный). Маршрут В.»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-40-marshrut-soglasovaniya-i-podpisaniya-dogovora.md](../marshruty/marshrut-40-marshrut-soglasovaniya-i-podpisaniya-dogovora.md) — Маршрут 40 «Маршрут согласования и подписания договора»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-41-vypusk-doverennosti.md](../marshruty/marshrut-41-vypusk-doverennosti.md) — Маршрут 41 «Выпуск доверенности»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
- [marshrut-42-nda-dohodnyy-marshrut-a.md](../marshruty/marshrut-42-nda-dohodnyy-marshrut-a.md) — Маршрут 42 «NDA (доходный). Маршрут А.»; запуск, участники, действия, переходы и неясности; черновик, не действующее правило.
## Карта выпуска — коллекция materialy

- [00-karta.md](00-karta.md) — карта всех файлов, границы подборки и словарь сокращений; где искать норму или описание.
- [izmeneniya-2026-05-11-2026-11-11.md](izmeneniya-2026-05-11-2026-11-11.md) — какие статьи подборки изменены законами за 11.05–11.11.2026 (115-ФЗ, ТК РФ); юристом не проверено.
- [poruchenie-chto-zacepit-izmenenie.md](poruchenie-chto-zacepit-izmenenie.md) — как найти затронутые изменением пункты договоров, вопросы бизнесу и проверить полноту.
- [poruchenie-pasport-proekta.md](poruchenie-pasport-proekta.md) — какие материалы нужны для паспорта, готовый текст задания, таблица Excel и проверка юристом.
- [shablon-pasporta-proekta.md](shablon-pasporta-proekta.md) — пустые разделы паспорта: участники, документы, деньги, данные, нормы, согласование и вопросы.
- [slovar-roley-marshrutov.md](slovar-roley-marshrutov.md) — 142 написания и 96 ролей; как сопоставлены сокращения и какие объединения ещё требуют ответа.
- [sverka-nda-a-21-42.md](sverka-nda-a-21-42.md) — сходство двух схем NDA А и неодинаковое чтение шага 8; почему нельзя объединять маршруты без решения.
## Карта выпуска — служебные файлы, НЕ знания

- [sistemnyy-prompt.md](../sistemnyy-prompt.md) — служебный: текст для системного поля; как отвечать по базе; не загружать в Knowledge.
- [kontrolnye-voprosy.md](../kontrolnye-voprosy.md) — служебный: 13 вопросов, эталоны и адреса; проверка загрузки, 2 текста отсутствуют; не загружать.
- [kak-zagruzit.md](../kak-zagruzit.md) — служебный: загрузка трёх коллекций, настройки администратора и пересборка; не загружать.
- [proverka-vypuska.md](../proverka-vypuska.md) — служебный: охват, ограничения, результаты проверок и SHA-256 исходников; не загружать.

## Карта выпуска — словарь сокращений

- ГК РФ — Гражданский кодекс Российской Федерации; здесь только подборка из части четвёртой.
- НК РФ — Налоговый кодекс Российской Федерации; здесь подборка из части второй.
- ТК РФ — Трудовой кодекс Российской Федерации.
- КоАП РФ — Кодекс Российской Федерации об административных правонарушениях.
- ЗоЗПП — Закон РФ «О защите прав потребителей», № 2300-1.
- ФЗ — федеральный закон; ПП РФ — постановление Правительства Российской Федерации.
- ПОД/ФТ — противодействие легализации (отмыванию) доходов и финансированию терроризма.
- ПДн — персональные данные; ЭП — электронная подпись; УКЭП — усиленная квалифицированная электронная подпись.
- СЭД — система электронного документооборота; ЭДО — электронный документооборот.
- NDA — соглашение о неразглашении; НМА — нематериальный актив; ЛНА — локальный нормативный акт.
- ГД — генеральный директор; ФД — финансовый директор; ЮД, ЮРДЕП — юридический департамент.
- ГПХ — гражданско-правовой характер; ФЛ — физическое лицо; ДКП — договор купли-продажи; ДС — дополнительное соглашение.
- ИБ — информационная безопасность; HR — работа с персоналом.
- СЭСД, АСПК, КДП, СВК, ДФМ, ОФП, ФО, КБ — полная расшифровка в схемах не подтверждена: не угадывать, вопросы в slovar-roley-marshrutov.md.
- БП и ОФМ — обозначения исходных групп схем; полная расшифровка в этом выпуске не утверждена.
- Knowledge — подключаемые коллекции знаний; Top K — число извлекаемых результатов поиска; oikb — программа синхронизации базы с GitLab из постановки.
